function translateCallback(transX, transY, CallbackFuncion) {
  translate(transX, transY)
  CallbackFuncion()
  translate(-transX, -transY)
}

function addBackground(
  paperColor, bgColor, isDotDrawn, dotColor,
  frameWidth, edgeWidth, dotDistance, dotSize
) {
  // 紙の描画
  background(paperColor)

  // 背景の描画
  translateCallback(width / 2, height / 2, () => {
    rectMode(CENTER)
    noStroke()
    fill(bgColor)
    rect(0, 0, floor(width - 2 * frameWidth), floor(height - 2 * frameWidth))
  })

  // グラデーション
  colorMode(RGB, 100)
  const img = createImage(
    floor(width - 2 * frameWidth),
    floor(height - 2 * frameWidth)
  )
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      img.set(x, y, color(100 * y / img.height, 50))
    }
  }
  img.updatePixels()
  image(img, frameWidth, frameWidth)

  // ドットの描画
  if (isDotDrawn) {
    translateCallback(width / 2, height / 2, () => {
      stroke(dotColor), strokeWeight(dotSize)
      for (
        let x = dotDistance / 2;
        x < floor(width / 2 - frameWidth) - edgeWidth;
        x += dotDistance
      ) {
        for (
          let y = dotDistance / 2;
          y < floor(height / 2 - frameWidth) - edgeWidth;
          y += dotDistance
        ) {
          rect(x, y, dotSize), rect(x, -y, dotSize), rect(-x, y, dotSize), rect(-x, -y, dotSize)
        }
      }
    })
  }

  // 枠線
  translateCallback(width / 2, height / 2, () => {
    stroke(paperColor === WHITE ? BLACK : WHITE)
    strokeWeight(BASE_LENGTH / 10), noFill()

    vertexX = width / 2 - frameWidth
    vertexY = height / 2 - frameWidth

    beginShape()
    for (let x = -vertexX; x <= vertexX; x++) {
      curveVertex(x, -vertexY + random(0, BASE_LENGTH / 32))
    }
    for (let y = -vertexY; y <= vertexY; y++) {
      curveVertex(vertexX + random(0, BASE_LENGTH / 32), y)
    }
    for (let x = vertexX; x >= -vertexX; x--) {
      curveVertex(x, vertexY + random(0, BASE_LENGTH / 32))
    }
    for (let y = vertexY; y >= -vertexY; y--) {
      curveVertex(-vertexX + random(0, BASE_LENGTH / 32), y)
    }
    endShape()
  })
}

function addSignature(string, font) {
  noStroke(), fill(BLACK)
  textFont(font), textSize(BASE_LENGTH * 0.75), textAlign(RIGHT, BOTTOM)
  text(string, width - BASE_LENGTH * 1.4, height - BASE_LENGTH * 1.4)
}

function drawShape(strokeColor, fillColor, func) {
  stroke(strokeColor)
  fill(fillColor)
  beginShape()
  func()
  endShape(CLOSE)
}

function drawRegularPolygon(centerX, centerY, r, offsetTheta, numVertex) {
  translateCallback(centerX, centerY, () => {
    beginShape()
    for (let theta = offsetTheta; theta < 360 + offsetTheta; theta += 360 / numVertex) {
      vertex(r * cos(radians(theta)), r * sin(radians(theta)))
    }
    endShape(CLOSE)
  })
}

function verticalLineTriangle(x1, y1, x2, y2, x3, y3, lineDash1, lineDash2) {
  let tmp
  if (x2 < x1) { tmp = x1, x1 = x2, x2 = tmp }
  if (x3 < x1) { tmp = x1, x1 = x3, x3 = tmp }
  if (x3 < x2) { tmp = x2, x2 = x3, x3 = tmp }

  triangle(x1, y1, x2, y2, x3, y3)

  drawingContext.setLineDash([lineDash1, lineDash2])
  for (let x = -width / 2; x < width / 2; x += BASE_LENGTH / 10) {
    if (x1 < x && x <= x2) {
      line(x, h(x), x, f(x))
    }
    if (x2 < x && x < x3) {
      line(x, h(x), x, g(x))
    }
  }
  drawingContext.setLineDash([])

  function f(x) {
    const a = (y1 - y2) / (x1 - x2)
    return a * x + y1 - a * x1
  }
  function g(x) {
    const a = (y2 - y3) / (x2 - x3)
    return a * x + y2 - a * x2
  }
  function h(x) {
    const a = (y3 - y1) / (x3 - x1)
    return a * x + y3 - a * x3
  }
}

function drawCursor(x, y, dotSize) {
  const cursor = [
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0],
    [1, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0],
    [1, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0],
    [1, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0],
    [1, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0],
    [1, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0],
    [1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0],
    [1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1],
    [1, 2, 2, 1, 2, 2, 1, 0, 0, 0, 0],
    [1, 2, 1, 0, 1, 2, 2, 1, 0, 0, 0],
    [1, 1, 0, 0, 1, 2, 2, 1, 0, 0, 0],
    [1, 0, 0, 0, 0, 1, 2, 2, 1, 0, 0],
    [0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0]
  ]

  const transX = x - dotSize * (cursor[0].length - 1) / 2
  const transY = y - dotSize * (cursor.length - 1) / 2

  translateCallback(transX, transY, () => {
    noStroke()
    for (let y = 0; y < cursor.length; y++) {
      for (let x = 0; x < cursor[0].length; x++) {
        if (cursor[y][x] === 0) fill("#0000")
        if (cursor[y][x] === 1) fill("#000F")
        if (cursor[y][x] === 2) fill("#FFFF")

        rect(dotSize * x, dotSize * y, dotSize)
        rect(dotSize * x, dotSize * y, dotSize)
        rect(dotSize * x, dotSize * y, dotSize)
        rect(dotSize * x, dotSize * y, dotSize)
      }
    }
  })
}

function drawSmile(x, y, dotSize, color) {
  const smile = [
    [0, 1, 0, 0, 1, 0],
    [0, 1, 0, 0, 1, 0],
    [0, 1, 0, 0, 1, 0],
    [0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 1],
    [0, 1, 1, 1, 1, 0]
  ]

  const transX = x - dotSize * (smile[0].length - 1) / 2
  const transY = y - dotSize * (smile.length - 1) / 2

  translateCallback(transX, transY, () => {
    noStroke()
    for (let y = 0; y < smile.length; y++) {
      for (let x = 0; x < smile[0].length; x++) {
        if (smile[y][x] === 0) fill("#0000")
        if (smile[y][x] === 1) fill(color)
        if (smile[y][x] === 2) fill("#FFFF")

        rect(dotSize * x, dotSize * y, dotSize)
        rect(dotSize * x, dotSize * y, dotSize)
        rect(dotSize * x, dotSize * y, dotSize)
        rect(dotSize * x, dotSize * y, dotSize)
      }
    }
  })
}

function addPaperTexure() {
  // ピクセルごとにノイズを乗せる
  rectMode(CORNER)
  colorMode(RGB, 100)

  const img = createImage(width, height)
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      img.set(x, y, color(100 * random(), 100 * random(), 100 * random(), 15))
    }
  }
  img.updatePixels(), image(img, 0, 0)

  // 繊維の描画
  stroke(color(255, 35)), strokeWeight(BASE_LENGTH / 300), noFill()
  for (let y = 0; y <= height; y += height / 200) {
    for (let x = 0; x <= width; x += width / 200) {
      beginShape()
      for (let i = 0; i < 4; i++) {
        curveVertex(x + randomGaussian(0, 10), y + randomGaussian(0, 10))
      }
      endShape()
    }
  }

  // 紙の色褪せの描画
  noStroke(), fill(color(100, 100, 0, 15))
  rect(0, 0, width, height)
}

function loadFonts() {
  // 等幅
  shareTechMono = loadFont("fonts/ShareTechMono-Regular.ttf")
  specialElite = loadFont("fonts/SpecialElite-Regular.ttf")

  // 手書き
  coveredByYourGrace = loadFont("fonts/CoveredByYourGrace-Regular.ttf")
  sedgwickAve = loadFont("fonts/SedgwickAve-Regular.ttf")
  rangaRegular = loadFont("fonts/Ranga-Regular.ttf")
  rangaBold = loadFont("fonts/Ranga-Bold.ttf")

  // 筆記体
  seaweedScript = loadFont("fonts/SeaweedScript-Regular.ttf")

  // ビットマップ
  silkscreenRegular = loadFont("fonts/Silkscreen-Regular.ttf")
  silkscreenBold = loadFont("fonts/Silkscreen-Bold.ttf")
  vt323 = loadFont("fonts/VT323-Regular.ttf")

  // バーコード
  libreBarcode39ExtendedText = loadFont("fonts/LibreBarcode39ExtendedText-Regular.ttf")
  libreBarcode39Extended = loadFont("fonts/LibreBarcode39Extended-Regular.ttf")

  // 日本語
  monomaniacOne = loadFont("fonts/MonomaniacOne-Regular.ttf")
  zenKurenaido = loadFont("fonts/ZenKurenaido-Regular.ttf")
  yujiHentaiganaAkari = loadFont("fonts/YujiHentaiganaAkari-Regular.ttf")
  yujiHentaiganaAkebono = loadFont("fonts/YujiHentaiganaAkebono-Regular.ttf")
}