function preload() { loadFonts() }

function setup() {
  SEED = floor(fxrand() * (10 ** 16))
  randomSeed(SEED)

  TITLE = "Twinkle"
  document.title = TITLE

  colorMode(HSB, 100)
  HUE = 100 * random(), SAT = 80, BRI = 80
  mainColor = color(HUE, SAT, BRI)
  complementaryColor = color((HUE + 50) % 100, SAT, BRI)
  BLACK = "#000", WHITE = "#FFF", GRAY = "#777"
  noLoop()

  // ここにdrawブロックから参照されるグローバル定数を定義する
  params = []
  for (let i = 0; i < 1000; i++) {
    params[i] = []
    for (let j = 0; j < 1000; j++) {
      params[i].push(randomGaussian())
    }
  }
}

function draw() {
  // 1 / 1, 672 / 504, 293.06 / 259.5, 135.53 / 255 
  ASPECT_RATIO = 1 / 1
  ASPECT_RATIO < windowHeight / windowWidth ?
    createCanvas(windowWidth, windowWidth * ASPECT_RATIO) :
    createCanvas(windowHeight / ASPECT_RATIO, windowHeight)

  BASE_LENGTH = min(width, height) / 25

  addBackground(
    WHITE, mainColor, false, BLACK,
    BASE_LENGTH, BASE_LENGTH / 2,
    BASE_LENGTH / 4, BASE_LENGTH / 20
  )
  addForeground()
  addSignature("なかがき", yujiHentaiganaAkari)
  addPaperTexure()
  fxpreview()

  function addForeground() {
    // 図形描画に関する各種初期化
    stroke(BLACK) // BLACK, WHITE, mainColor
    fill(mainColor) // BLACK, WHITE, mainColor
    strokeCap(ROUND) // ROUND, SQUARE, PROJECT
    strokeJoin(ROUND) // MITER, BEVEL, ROUND
    strokeWeight(BASE_LENGTH / 5)
    rectMode(CENTER)
    textAlign(CENTER, CENTER)

    translateCallback(width / 2, height / 2, () => {
      noFill()

      beginShape()
      vertex(0.12 * width * params[0][0], 0.12 * height * params[0][1])
      for (let j = 2; j < 6 * 50 + 2; j += 6) {
        bezierVertex(
          0.12 * width * params[0][j], 0.12 * height * params[0][j + 1],
          0.12 * width * params[0][j + 2], 0.12 * height * params[0][j + 3],
          0.12 * width * params[0][j + 4], 0.12 * height * params[0][j + 5]
        )
      }
      endShape()

      noStroke(), fill(BLACK)

      for (let i = 0; i < 800; i++) {
        r = BASE_LENGTH / 5 * params[1][i + 2]
        circle(
          0.12 * width * params[1][i],
          0.12 * height * params[1][i + 1],
          0 < r ? r : 0
        )
      }

      noFill()
      stroke(WHITE)
      strokeWeight(BASE_LENGTH / 5 - BASE_LENGTH / 8)

      beginShape()
      vertex(0.12 * width * params[0][0], 0.12 * height * params[0][1])
      for (let j = 2; j < 6 * 50 + 2; j += 6) {
        bezierVertex(
          0.12 * width * params[0][j], 0.12 * height * params[0][j + 1],
          0.12 * width * params[0][j + 2], 0.12 * height * params[0][j + 3],
          0.12 * width * params[0][j + 4], 0.12 * height * params[0][j + 5]
        )
      }
      endShape()

      noStroke(), fill(WHITE)
      for (let i = 0; i < 800; i++) {
        r = BASE_LENGTH / 5 * params[1][i + 2] - BASE_LENGTH / 8
        circle(
          0.12 * width * params[1][i],
          0.12 * height * params[1][i + 1],
          0 < r ? r : 0
        )
      }

      drawSmile(0, 0, BASE_LENGTH / 4, BLACK)
    })
  }
}

function windowResized() {
  draw()
}

function keyTyped() {
  if (key === 's') { saveCanvas(TITLE + "#" + SEED) }
}